
const dino = document.getElementById("dino");
const cactus = document.getElementById("cactus");
const bird = document.getElementById("bird");
const scoreEl = document.getElementById("score");

let jumping = false;
let score = 0;

let bgMusic = new Audio("assets/bg.mp3");
let gameOverSound = new Audio("assets/gameover.mp3");

bgMusic.loop = true;
bgMusic.volume = 0.5;
bgMusic.play();

document.addEventListener("keydown", function (e) {
  if (e.code === "Space" && !jumping) {
    jump();
  }
});

function jump() {
  jumping = true;
  let height = 0;
  let upInterval = setInterval(() => {
    if (height >= 100) {
      clearInterval(upInterval);
      let downInterval = setInterval(() => {
        if (height <= 0) {
          clearInterval(downInterval);
          jumping = false;
        } else {
          height -= 5;
          dino.style.bottom = height + "px";
        }
      }, 20);
    } else {
      height += 5;
      dino.style.bottom = height + "px";
    }
  }, 20);
}

function moveCactus() {
  let cactusLeft = 500;
  let move = setInterval(() => {
    if (cactusLeft < -20) {
      cactusLeft = 500;
      score++;
      scoreEl.textContent = score;
    } else {
      cactusLeft -= 5;
    }

    cactus.style.right = (window.innerWidth - cactusLeft) + "px";

    let dinoBottom = parseInt(window.getComputedStyle(dino).bottom);
    if (cactusLeft > 50 && cactusLeft < 90 && dinoBottom < 40) {
      gameOverSound.play();
      alert("O‘yin tugadi! Ochko: " + score);
      location.reload();
    }
  }, 20);
}

function moveBird() {
  let birdLeft = 600;
  let move = setInterval(() => {
    if (birdLeft < -30) {
      birdLeft = 600;
    } else {
      birdLeft -= 4;
    }
    bird.style.right = (window.innerWidth - birdLeft) + "px";

    let dinoBottom = parseInt(window.getComputedStyle(dino).bottom);
    if (birdLeft > 50 && birdLeft < 90 && dinoBottom > 50) {
      gameOverSound.play();
      alert("O‘yin tugadi! Ochko: " + score);
      location.reload();
    }
  }, 30);
}

moveCactus();
moveBird();
